
- - - - - - - - - - - - - - - - - - - - 
END USER LICENCE AGREEMENT
- - - 
DEMO LICENCE
- - - - - - - - - - - - - - - - - - - - 

Screenshots of the online type tester or our PDF specimens are not always enough to create a nice presentation for your client. Therefore, we offer Demo-Fonts for our complete Font Collection. You may use them for layouts, presentations or pitches to convince you and your client to purchase the fonts finally.

- - - - - - - - - - - - - - - - - - - - 

Demo-Fonts are meant for testing or demonstration purposes. They allow you to use the fonts for testing exclusively and come along with a reduced character set and no OpenType Features.

The following is an agreement between you (the user/licencee) and the foundry TypeMates (licencer / TypeMates, Runge Thomsen GbR). If you do not accept these terms, you will not be able to purchase the font software licence and you may not use the fonts.

What you are purchasing from TypeMates is a licence to use our fonts (font software). You are purchasing the rights to use the fonts with respect to the following terms and conditions. You are not purchasing the copyright of the typeface.

Depending on the license, our fonts will be delivered in the following formats: OpenType (OTF), TrueType (TTF), as well as WebFont formats (EOT, WOFF, WOFF2). Additional formats are available on request, but may require an additional licence.


- - -
WITH THE PURCHASE OR INSTALLATION OF OUR FONTS YOU AGREE TO THE FOLLOWING:

You may install the DemoFonts on your computer to generate graphics, or PDFs, to convince yourself and your client. You should licence the original font —without ‘DEMO’ in its name— for the final and commercial artwork.

You may embed the DemoFonts in static documents (e.g. PDFs) to present them to your client. However, you have to take care they are securely embedded (in read/print-only mode), ensuring the recipient cannot extract the fonts to use them.

You may not convert the fonts to other font formats, nor may you modify, decompile or instruct a third party to convert, modify or decompile them.

You may not sell, sublicence nore share the DemoFonts. 

You may not embed the font files in e-books, application, in other software or hardware, or host files on the web without a proper licence. Contact us, or just purchase one directly in our shop.

The licence is not transferable.

The use of our DemoFonts includes the subscription of our newsletter.

- - -
WARRANTY AND LIMITATION OF LIABILITY
 TypeMates fonts can be returned or replaced only if they are defective. Defective fonts will be replaced if you have a valid proof of purchase and inform us about the error within 30 days of purchase. This warranty does not apply to font data that has been converted, manipulated or altered by you. If not caused by gross negligence or malicious intent by us, TypeMates shall not be liable for any consequences, property or legal responsibility — including, but not limited to, lost profits and/or lost data — as a consequence of using our fonts.

TERMINATION 
Any violation of this agreement by you, the licensee, will terminate this license. In case of termination, you are obligated to immediately remove all our fonts and all copies from your system and certify this to us, the licensor.

JURISDICTION
 This Agreement shall be governed by the laws of the Federal Republic of Germany. This Agreement shall not be subject to the United Nations Convention on the International Sale of Goods, the application of which is expressly excluded. The court of jurisdiction is in Hamburg, Germany.

MISCELLANEOUS 
TypeMates reserves the right to modify this license at any time without notice. However, it will not restrict your previously purchased rights within the license. Should a regulation of this contract be invalid in whole or part, the validity of other regulations shall remain unaffected.

CONTACT
 In case of doubt or other questions please contact us at any time: Please send inquiries by e-mail to hej@typemates.com. On our website www.typemates.com you can also find our telephone and postal contacts.  

- - - - - - - - - - - - - - - - - - - - 

Version 2.0
February 2018

